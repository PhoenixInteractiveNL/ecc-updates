--------------------------------------------------------------------------------
- This is the emuControlCenter userfolder!
- You can get the latest version of ECC at http://ecc.phoenixinteractive.nl/
- With ecc, you can manage your roms in an easier way!
--------------------------------------------------------------------------------

This folder could contains data various platforms