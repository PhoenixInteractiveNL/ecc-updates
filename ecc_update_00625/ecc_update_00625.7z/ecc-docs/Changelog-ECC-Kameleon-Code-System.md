## Changelog ECC Kameleon Code System
***
v1.0.0.2 (2014.03.28)
- Combined all global variables in the script eccToolVariables

v1.0.0.1 (2012.09.27)
- Fixed "empty" code for script when pressing cancel or closing the GUI.

v1.0.0.0 (2012.05.03)
- Initial release