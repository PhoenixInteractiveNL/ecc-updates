## Convert XML to CLR MAME datfile
***
* datutil convert command:

`datutil.exe -f cmp file.xml`

This will output a file called: 'datutil.dat', that will be in the old style CLRMAME Pro format.

Example of datutil in action, converting an MAME 0.130 XML DAT:

![](https://raw.githubusercontent.com/wiki/PhoenixInteractiveNL/emuControlCenter/images/img_datutil_screen.png)