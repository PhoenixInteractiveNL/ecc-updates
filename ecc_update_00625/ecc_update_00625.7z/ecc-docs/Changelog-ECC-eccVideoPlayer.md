## Changelog ECC eccVideoPlayer
***
v2.0.0.1 (2014.05.10)
- Fixed video window flashing when giving focus back to ECC

v2.0.0.0 (2014.05.04)
- New initial release that uses 'Mplayer' instead of VLC activeX plugin.

v1.1.0.4 (2014.03.28)
- Combined all global variables in the script eccToolVariables

v1.1.0.3 (2012.11.11)
- Using soundvolume variable used from the ECC config.
- Adjusted default settings

v1.1.0.2 (2012.11.11)
- Fixed a bug where a new video is getting played when added while the ECC
video player settings are off.
- Fixed a bug in the messagebox that is shown if VLC cannot be initialized.

v1.1.0.1 (2012.11.10)
- Now stops the video if a rom is being deleted in ECC.
- Added message (tooltip) if the ECC main window cannot be found.

v1.1.0.0 (2012.11.10)
- Added configurable variables used from the ECC config.
- Autodisable video player if VLC is not found!