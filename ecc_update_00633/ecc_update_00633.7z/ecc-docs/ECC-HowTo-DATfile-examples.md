## ECC HowTo DATfile examples
***
## MAME
[_HowTo - Extract the XML list from MAME executable_](https://github.com/PhoenixInteractiveNL/emuControlCenter/wiki/HowTo-Extract-XML-list-from_MAME_executable)

[_HowTo - Write ECC Platform DATfiles from MAME XML list_](https://github.com/PhoenixInteractiveNL/emuControlCenter/wiki/HowTo-Write-ECC-Platform-DATfiles-from- MAME -XML-list)
## DATFILE
[_HowTo - Convert XML to CLR MAME datfile_](https://github.com/PhoenixInteractiveNL/emuControlCenter/wiki/HowTo-Convert-XML-to-CLR-MAME-datfile)

[_HowTo - Convert XML to CSV file_](https://github.com/PhoenixInteractiveNL/emuControlCenter/wiki/HowTo-Convert-XML-to-CSV-file)