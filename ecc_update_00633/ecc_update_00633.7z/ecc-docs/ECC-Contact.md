You can mail any questions regarding emuControlCenter to

:envelope: phoenixinteractive#hotmail*com (replace # with @, and * with .)

:warning: NOTE: Start with "ECC" on the subject, otherwise the mail will be ignored!

Please be patient for a reply, i am a very busy man! :grinning: