## HowTo Extract XML list from MAME
***
You can use the following command to extract an XML list form the MAME EXE file:

    mame.exe -listxml >mame.dat

or

    mameui32.exe -listxml >mame.dat