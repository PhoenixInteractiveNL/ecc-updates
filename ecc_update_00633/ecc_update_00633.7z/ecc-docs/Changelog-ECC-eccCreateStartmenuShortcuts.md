## Changelog ECC eccCreateStartmenuShortcuts
***
v1.0.0.4 (ECC v1.21)
- Now fetching website link from toolvariables.au3

v1.0.0.3 (2014.03.28)
- Combined all global variables in the script eccToolVariables
- Changed URL's to form MINE.NU to .NL (due to changing webadres)

v1.0.0.2 (2012.08.11)
- Adjusted creating of shortcuts to use eccUpdate instead of ECC Live! 

v1.0.0.1 (2012.05.06)
- Improved ECC path fetching.

v1.0.0.0 (2012.05.05)
- Initial release