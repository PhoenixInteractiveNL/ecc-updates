## Changelog ECC eccDiagnostics
***
v1.0.0.4
- Adjusted CID checks to UID.

v1.0.0.3 (2014.03.28)
- Combined all global variables in the script eccToolVariables

v1.0.0.2 (2012.11.19)
- Fixed scanning files to only scan files inside the ecc-core folder.

v1.0.0.1 (2012.05.06)
- Fixed messagebox titles, now all consistend en right!
- Improved ECC path fetching.
- Adjusted for new ECC script adressing (without BAT file)

v1.0.0.0 (2012.02.16)
- Initial release