## Changelog ECC 3D Gallery
***
v1.2.0.1 (ECC v1.21)
- Adjusted variable to fetch the proper websitelink from toolvariables.au3

v1.2.0.0 (2014.04.23)
- Fixed a bug in the scrollbox, the scrollbar did not appear.
- Updated gallery's
 - simpleviewer
 - tiltviewer
- Added gallery's from flashxml.net:
 - 3dphotorotator
 - 3dphotozoom
 - circulargallery
  - polaroidgalleryfx

v1.1.0.8 (2014.03.28)
- Combined all global variables in the script eccToolVariables
- Changed URL's to form MINE.NU to .NL (due to changing webadres)

v1.1.0.7 (2012.11.19)
- Adjusted code to use 'cover_3d' instead of 'cover_inlay_03'.

v1.1.0.6 (2012.11.09)
- Adjusted the rom INI information to the new ECC 'selectedrom' triggersystem.

v1.1.0.5 (2012.10.14)
- Added hotkey ESCAPE to close the gallery.
- Converted messageboxes into tooltips.

v1.1.0.4 (2012.07.06)
- Fixed broken view on startup wich sometimes occured.

v1.1.0.3 (2012.07.04)
- Added new gallery: flshowcarouselblack (http://www.flshow.net)
- Added missing preview image for gallery 'tiltviewer'.
- Resized all preview images to fit better in the gallery configuration GUI (smoother)

v1.1.0.2 (2012.05.06)
- Improved ECC path fetching.
- Adjusted for new ECC script addressing (without BAT file)

v1.1.0.1 (2012.05.05)
- Added window border to the GUI
- Updated ICON for Kameleon Code

v1.1.0.0 (2012.04.26)
- Added configuration screen (GUI).
- 5 new gallery's added:
- postcardviewer (http://www.simpleviewer.net/products)
- simpleviewer (http://www.simpleviewer.net/products)
- 3dtouchring (http://www.flashmo.com)
- 3dcurvegallery (http://www.flashmo.com)
- polaroid gallery (http://www.no3dfx.com/polaroid)
- Added 3D Gallery icon to the titlebar/taskbar.
- Added several error handlers.
- Fixed proper file loading (only images)

v1.0.0.0 (2012.04.09)
- Initial release