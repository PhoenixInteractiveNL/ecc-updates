## HowTo Debug ECC PHP code
***
You can debug ECC PHP code the following way:

* From ECC root folder execute:

`ecc-core\php-gtk2\php.exe -c ecc-core\php-gtk2\php.ini ecc-system\ecc.php`

Now you can use **ECHO** and **PRINT** commands within **ecc.php** to debug output data.