## Changelog ECC GtkThemeSelect (GTKTS)
***
v1.0.0.3 (2014.03.28)
- Combined all global variables in the script eccToolVariables

v1.0.0.1 (2011.05.06)
- Improved ECC path fetching.
- Adjusted for new ECC script addressing (without BAT file)

v1.0.0.0 (2011.05.05)
- Initial release