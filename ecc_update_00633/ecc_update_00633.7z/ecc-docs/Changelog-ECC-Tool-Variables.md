## Changelog ECC Tool Variables
***
v1.0.2.0
- Added EDC variables.

v1.0.1.0
- Added UID string.

v1.0.0.9 (2016.09.25)
- Removed Xpadder variable, added JoyEmulator variable.

v1.0.0.8 (ECC v1.21)
- Added new variables for eccdb, now reading ecc settings.
- Fixed an issue where the database could not be found at the "default" location.

v1.0.0.6 (2014.06.24)
- Updated allround variables for EmuMovies downloader (EMD)

v1.0.0.1 (2014.03.29)
- Updated variables in eccToolVariables

v1.0.0.0 (2014.03.28)
- Combined all global variables in the script eccToolVariables