## Changelog ECC Theme select (discontinued, now GtkThemeSelect)
***
v1.1.0.6 (2008.05.18)
- Adjusted all paths to the new 'ecc-core' structure.

v1.1.0.5 (2008.05.03)
- Improved ECC Core detecion, so that ECC software can be found.

v1.1.0.4 (2007.09.30)
- Adjusted to look in the right ECC core folder for the themes.

v1.1.0.3 (2007.09.30)
- Fixed an running issue on Win98 systems (and maybe other OS'es).

v1.1.0.2 (2007.05.02)
- Fixed 'HALT' on Japanese / Chinese systems.
-The 'self validation' check on the tools that where incompatible/conflicting.
with japanese / chinese charsets, hopefully this is fixed now.

v1.1.0.0 (2007.04.20)
- White edition.
- Added XP look.
- Added tooltips on the buttons.

v1.0.0.9 (2007.02.28)
- Auto highlight theme in list on startup has been fixed.

v1.0.0.8 (2007.02.24)
- Updated ECC Theme Select for the 'Global GUI font' config for ECC v0.7.5+

v1.0.0.7 (2007.02.14)
- Updated for the 'new GTK v2.10.7 engine', corrected the path to '2.10.0'.

v1.0.0.6 (2007.02.03)
- Autoexit Theme Select when ECC is started from within Theme Select

v1.0.0.5 (2007.01.23)
- Error handling when 'gtkrc' is read only. (like when executing from CD/DVD)
- Removed the 'more info' section, now in ECC info.
- Removed the 'tooltip help icons', now in ECC info.
- Only one instance could be active.
- Version number displaying in windows explorer. 
- Improved anti hack integration.
- Improved the exit routine.
- Can only run from the ECC-TOOLS folder. (fix)
- Added splashscreen. (2 sec) 
- UPX compressed.

v1.0.0.2 (2007.01.16)
- Changed name from 'ECC Theme selector' to 'ECC theme select'
- Now running from the ECC-TOOLS folder.
- All windows now startup on center screen.
- Added a small fix to not display files in the listbox.

v1.0.0.1 (2007.01.12)
- Some text replacement in the notes section.
- Renamed some 'GOODSKIN' words to 'GOODTHEME'
- Made the 'more notes' box a little bit bigger.
- Fixed the 'more notes' icon on the button.

v1.0.0.0 (2007.01.11)
- Initial release