## Changelog ECC eccThirdPartyConfig
***
v1.0.0.3 (2016.09.25)
- Removed Xpadder config.

v1.0.0.2 (2014.03.28)
- Combined all global variables in the script eccToolVariables

v1.0.0.1 (2012.07.04)
- Fixed a bug where the usersetting wasn't saved properly, causing ThirdPartyConfig not to work as it should.

v1.0.0.0 (2012.05.13)
- Initial release