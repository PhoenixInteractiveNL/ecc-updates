## Notes
***
### ZIP Parser
MAME, Arcade and Dosbox files/roms only work when they are ZIPped.
These multiple packed files will use the ZIP parser and are NOT processed
when compressed with 7Zip or RAR.

***
### Kameleon Code
After entering the kameleon code you have to select the service again to make use of it.

***
### Administrator rights
If you don't have Admin rights on this machine you can expect READ-ONLY behavior with ECC!!

***
### More instances of ECC running
Running more then one instance of ECC at the same install location is NOT advisable!! your ECC database could be damaged!

***
### Minimal width resolution of 1000 pixels
Your useable WIDTH resolution to display ECC, should be more then 1000 pixels, otherwise you can expect GUI glitching or the GUI does not work at all ! (this may occur when you have set the taskbar on the side @ 1024x768)

***
### Setting and using the ECC DATABASE path
- With manual input always use a ending slash \.
- Network paths are not listed, but you can type them manually like: \\COMPUTER\PATH\.
- Wrong pathnames or no rights to write will reset the DB tot he default "ecc-system\database" location.
- When configuring a location of a existing ECC configuration/database, you have to copy the database manually to the new location.
- You may experience slow response form ECC when you store the datbaase on a network path.
- ECC is not tested to run from multiple computers with the same database, the database could be "in use by another application" let me know if it works!