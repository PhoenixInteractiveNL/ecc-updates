## Links and Partners
***
![](https://raw.githubusercontent.com/wiki/PhoenixInteractiveNL/emuControlCenter/images/img_logo_emumovies.png)

[http://emumovies.com](http://emumovies.com)
***
![](https://raw.githubusercontent.com/wiki/PhoenixInteractiveNL/emuControlCenter/images/img_logo_emufrance.png)

[http://www.emu-france.com](http://www.emu-france.com)
***
![](https://raw.githubusercontent.com/wiki/PhoenixInteractiveNL/emuControlCenter/images/img_logo_nointro.png)

[http://no-intro.dlgsoftware.net/main.php?lang=1](http://no-intro.dlgsoftware.net/main.php?lang=1)
***